CREATE TABLE [dbo].[Suppliers] (
    [SupplierId]  INT            IDENTITY (1, 1) NOT NULL,
    [Name]        NVARCHAR (150) NOT NULL,
    [PhoneNumber] NVARCHAR (20)  NULL,
    [Address]     NVARCHAR (255) NULL,
    [Email]       NVARCHAR (100) NULL,
    CONSTRAINT [PK_Suppliers] PRIMARY KEY CLUSTERED ([SupplierId] ASC)
);

