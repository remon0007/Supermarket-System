CREATE TABLE [dbo].[SaleItems] (
    [SaleItemId] INT             IDENTITY (1, 1) NOT NULL,
    [SaleId]     INT             NOT NULL,
    [ProductId]  INT             NOT NULL,
    [Quantity]   INT             NOT NULL,
    [UnitPrice]  DECIMAL (18, 2) NOT NULL,
    [SaleId1]    INT             NULL,
    CONSTRAINT [PK_SaleItems] PRIMARY KEY CLUSTERED ([SaleItemId] ASC),
    CONSTRAINT [FK_SaleItems_Products_ProductId] FOREIGN KEY ([ProductId]) REFERENCES [dbo].[Products] ([ProductId]),
    CONSTRAINT [FK_SaleItems_Sales_SaleId] FOREIGN KEY ([SaleId]) REFERENCES [dbo].[Sales] ([SaleId]) ON DELETE CASCADE,
    CONSTRAINT [FK_SaleItems_Sales_SaleId1] FOREIGN KEY ([SaleId1]) REFERENCES [dbo].[Sales] ([SaleId])
);


GO
CREATE NONCLUSTERED INDEX [IX_SaleItems_ProductId]
    ON [dbo].[SaleItems]([ProductId] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_SaleItems_SaleId]
    ON [dbo].[SaleItems]([SaleId] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_SaleItems_SaleId1]
    ON [dbo].[SaleItems]([SaleId1] ASC);

