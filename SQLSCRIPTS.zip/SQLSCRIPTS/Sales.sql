CREATE TABLE [dbo].[Sales] (
    [SaleId]      INT             IDENTITY (1, 1) NOT NULL,
    [SaleDate]    DATETIME2 (7)   NOT NULL,
    [TotalAmount] DECIMAL (18, 2) NOT NULL,
    [ItemCount]   INT             NOT NULL,
    CONSTRAINT [PK_Sales] PRIMARY KEY CLUSTERED ([SaleId] ASC)
);

