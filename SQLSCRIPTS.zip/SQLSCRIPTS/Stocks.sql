CREATE TABLE [dbo].[Stocks] (
    [StockId]         INT            IDENTITY (1, 1) NOT NULL,
    [ProductId]       INT            NOT NULL,
    [QuantityAdded]   INT            NOT NULL,
    [TransactionDate] DATETIME2 (7)  NOT NULL,
    [Notes]           NVARCHAR (500) NULL,
    CONSTRAINT [PK_Stocks] PRIMARY KEY CLUSTERED ([StockId] ASC),
    CONSTRAINT [FK_Stocks_Products_ProductId] FOREIGN KEY ([ProductId]) REFERENCES [dbo].[Products] ([ProductId]) ON DELETE CASCADE
);


GO
CREATE NONCLUSTERED INDEX [IX_Stocks_ProductId]
    ON [dbo].[Stocks]([ProductId] ASC);

