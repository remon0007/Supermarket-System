CREATE TABLE [dbo].[Products] (
    [ProductId]       INT             IDENTITY (1, 1) NOT NULL,
    [Name]            NVARCHAR (150)  NOT NULL,
    [Barcode]         NVARCHAR (50)   NOT NULL,
    [Brand]           NVARCHAR (100)  NULL,
    [Price]           DECIMAL (18, 2) NOT NULL,
    [QuantityInStock] INT             NOT NULL,
    [ExpiryDate]      DATETIME2 (7)   NULL,
    [RestockDate]     DATETIME2 (7)   NULL,
    [CategoryId]      INT             NOT NULL,
    [SupplierId]      INT             NOT NULL,
    CONSTRAINT [PK_Products] PRIMARY KEY CLUSTERED ([ProductId] ASC),
    CONSTRAINT [FK_Products_Categories_CategoryId] FOREIGN KEY ([CategoryId]) REFERENCES [dbo].[Categories] ([CategoryId]) ON DELETE CASCADE,
    CONSTRAINT [FK_Products_Suppliers_SupplierId] FOREIGN KEY ([SupplierId]) REFERENCES [dbo].[Suppliers] ([SupplierId])
);


GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_Products_Barcode]
    ON [dbo].[Products]([Barcode] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_Products_CategoryId]
    ON [dbo].[Products]([CategoryId] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_Products_SupplierId]
    ON [dbo].[Products]([SupplierId] ASC);

