﻿using Xunit;
using SupermarketSystem.Models;
using SupermarketSystem.Services;
using SupermarketSystem.Data;
using SupermarketSystem.DataStructures;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SupermarketSystem.Tests
{
    public class SupermarketServiceTests
    {
        private SupermarketService CreateService()
        {
            return new SupermarketService();
        }

        // ==================== PRODUCT OPERATIONS TESTS ====================

        [Fact]
        public void AddProduct_ValidProduct_Success()
        {
            // Arrange
            var service = CreateService();
            var productCount = service.GetAllProducts().Count;

            // Act
            service.AddProduct(
                "Test Product",
                "TEST001",
                "TestBrand",
                10.99m,
                50,
                1,
                1,
                DateTime.Now.AddDays(30)
            );

            // Assert
            var allProducts = service.GetAllProducts();
            Assert.True(allProducts.Count > productCount);
            Assert.NotNull(allProducts.FirstOrDefault(p => p.Barcode == "TEST001"));
        }

        [Fact]
        public void AddProduct_InvalidPrice_ThrowsException()
        {
            // Arrange
            var service = CreateService();

            // Act & Assert
            Assert.Throws<ArgumentException>(() =>
                service.AddProduct("Test", "BAR001", "Brand", -5m, 10, 1, 1, null)
            );
        }

        [Fact]
        public void AddProduct_DuplicateBarcode_ThrowsException()
        {
            // Arrange
            var service = CreateService();

            // Act & Assert
            Assert.Throws<ArgumentException>(() =>
                service.AddProduct("Milk", "1001", "FarmFresh", 3.50m, 25, 1, 1, null)
            );
        }

        [Fact]
        public void UpdateProductStock_ValidProduct_Success()
        {
            // Arrange
            var service = CreateService();
            var products = service.GetAllProducts();
            var product = products.FirstOrDefault();

            // Act
            service.UpdateProductStock(product.ProductId, 100);

            // Assert
            var updated = service.GetAllProducts().FirstOrDefault(p => p.ProductId == product.ProductId);
            Assert.Equal(100, updated.QuantityInStock);
        }

        [Fact]
        public void RemoveProduct_ValidProduct_Success()
        {
            // Arrange
            var service = CreateService();
            service.AddProduct("Remove Test", "REMOVE001", "Brand", 5.00m, 10, 1, 1, null);
            var products = service.GetAllProducts();
            var toRemove = products.FirstOrDefault(p => p.Barcode == "REMOVE001");

            // Act
            service.RemoveProduct(toRemove.ProductId);

            // Assert
            var remaining = service.GetAllProducts();
            Assert.Null(remaining.FirstOrDefault(p => p.ProductId == toRemove.ProductId));
        }

        // ==================== SEARCH ALGORITHM TESTS ====================

        [Fact]
        public void SearchProductByName_ExistingProduct_ReturnsProduct()
        {
            // Arrange
            var service = CreateService();

            // Act
            var results = service.SearchProductByName("Milk");

            // Assert
            Assert.NotEmpty(results);
            Assert.Contains(results, p => p.Name.Contains("Milk", StringComparison.OrdinalIgnoreCase));
        }

        [Fact]
        public void SearchProductByName_NonExistingProduct_ReturnsEmpty()
        {
            // Arrange
            var service = CreateService();

            // Act
            var results = service.SearchProductByName("NonExistentProduct12345");

            // Assert
            Assert.Empty(results);
        }

        [Fact]
        public void SearchProductByBarcode_ExistingBarcode_ReturnsProduct()
        {
            // Arrange
            var service = CreateService();

            // Act
            var product = service.SearchProductByBarcode("1001");

            // Assert
            Assert.NotNull(product);
            Assert.Equal("1001", product.Barcode);
        }

        [Fact]
        public void SearchProductByBarcode_NonExistingBarcode_ReturnsNull()
        {
            // Arrange
            var service = CreateService();

            // Act
            var product = service.SearchProductByBarcode("NONEXISTENT");

            // Assert
            Assert.Null(product);
        }

        [Fact]
        public void SearchByCategory_ValidCategory_ReturnsProducts()
        {
            // Arrange
            var service = CreateService();

            // Act
            var results = service.SearchByCategory(1); // Dairy

            // Assert
            Assert.NotEmpty(results);
            Assert.All(results, p => Assert.Equal(1, p.CategoryId));
        }

        [Fact]
        public void SearchBySupplier_ValidSupplier_ReturnsProducts()
        {
            // Arrange
            var service = CreateService();

            // Act
            var results = service.SearchBySupplier(1);

            // Assert
            Assert.NotEmpty(results);
            Assert.All(results, p => Assert.Equal(1, p.SupplierId));
        }

        // ==================== STOCK MANAGEMENT TESTS ====================

        [Fact]
        public void GetLowStockAlerts_ReturnsProductsWithLowStock()
        {
            // Arrange
            var service = CreateService();

            // Act
            var lowStockProducts = service.GetLowStockAlerts();

            // Assert
            Assert.All(lowStockProducts, p => Assert.True(p.QuantityInStock < 10));
        }

        [Fact]
        public void RestockProduct_ValidProduct_IncreasesStock()
        {
            // Arrange
            var service = CreateService();
            var products = service.GetAllProducts();
            var product = products.FirstOrDefault();
            var initialStock = product.QuantityInStock;

            // Act
            service.RestockProduct(product.ProductId, 50);

            // Assert
            var updated = service.GetAllProducts().FirstOrDefault(p => p.ProductId == product.ProductId);
            Assert.Equal(initialStock + 50, updated.QuantityInStock);
        }

        // ==================== SALES MANAGEMENT TESTS ====================

        [Fact]
        public void RecordSale_ValidItems_CreatesSale()
        {
            // Arrange
            var service = CreateService();
            var items = new List<(int productId, int quantity)>
            {
                (1, 2)  // Product ID 1, Quantity 2
            };

            // Act
            int saleId = service.RecordSale(items);

            // Assert
            Assert.True(saleId > 0);
        }

        [Fact]
        public void RecordSale_InsufficientStock_ThrowsException()
        {
            // Arrange
            var service = CreateService();
            var items = new List<(int productId, int quantity)>
            {
                (1, 10000)  // Extremely high quantity
            };

            // Act & Assert
            Assert.Throws<ArgumentException>(() => service.RecordSale(items));
        }

        [Fact]
        public void RecordSale_DecreasesProductStock()
        {
            // Arrange
            var service = CreateService();
            var product = service.GetAllProducts().FirstOrDefault();
            var initialStock = product.QuantityInStock;

            var items = new List<(int productId, int quantity)>
            {
                (product.ProductId, 5)
            };

            // Act
            service.RecordSale(items);

            // Assert
            var updated = service.GetAllProducts().FirstOrDefault(p => p.ProductId == product.ProductId);
            Assert.Equal(initialStock - 5, updated.QuantityInStock);
        }

        // ==================== DATA STRUCTURE TESTS ====================

        [Fact]
        public void ProductBST_Insert_AddsProduct()
        {
            // Arrange
            var bst = new ProductBST();
            var product = new Product { ProductId = 1, Name = "Test", Barcode = "TEST" };

            // Act
            bst.Insert(product);

            // Assert
            Assert.Equal(1, bst.Count);
        }

        [Fact]
        public void BarcodeHashTable_AddAndSearch_ReturnsProduct()
        {
            // Arrange
            var hashTable = new BarcodeHashTable();
            var product = new Product { ProductId = 1, Name = "Test", Barcode = "TEST123" };

            // Act
            hashTable.Add("TEST123", product);
            var result = hashTable.Search("TEST123");

            // Assert
            Assert.NotNull(result);
            Assert.Equal("TEST123", result.Barcode);
        }

        [Fact]
        public void BarcodeHashTable_Remove_DeletesProduct()
        {
            // Arrange
            var hashTable = new BarcodeHashTable();
            var product = new Product { ProductId = 1, Name = "Test", Barcode = "TEST456" };
            hashTable.Add("TEST456", product);

            // Act
            hashTable.Remove("TEST456");
            var result = hashTable.Search("TEST456");

            // Assert
            Assert.Null(result);
        }

        // ==================== VALIDATION TESTS ====================

        [Fact]
        public void AddProduct_NegativeQuantity_ThrowsException()
        {
            // Arrange
            var service = CreateService();

            // Act & Assert
            Assert.Throws<ArgumentException>(() =>
                service.AddProduct("Test", "BAR999", "Brand", 10m, -5, 1, 1, null)
            );
        }

        [Fact]
        public void AddProduct_InvalidExpiryDate_Handled()
        {
            // Arrange
            var service = CreateService();

            // Act - Should handle past dates without throwing
            service.AddProduct(
                "Test Product",
                "PAST001",
                "Brand",
                5.00m,
                10,
                1,
                1,
                DateTime.Now.AddDays(-5)  // Past date
            );

            // Assert
            var product = service.SearchProductByBarcode("PAST001");
            Assert.NotNull(product);
        }
    }
}